package com.option.refit.domain.user.repository;


import com.option.refit.domain.user.entity.User;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    boolean existsByEmailId(String emailId);

    Optional<User> findByIdAndDeletedAtIsNull(Long id);
}
